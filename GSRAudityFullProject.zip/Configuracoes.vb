﻿Public Class Configuracoes

End Class