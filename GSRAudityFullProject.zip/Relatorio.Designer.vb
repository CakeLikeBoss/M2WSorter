﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormRelatorio
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TextBoxPesquisa = New System.Windows.Forms.TextBox()
        Me.LabelCodigoRef = New System.Windows.Forms.Label()
        Me.ButtonInicio = New System.Windows.Forms.Button()
        Me.ButtonPesquisar = New System.Windows.Forms.Button()
        Me.DataGridViewRelatorio = New System.Windows.Forms.DataGridView()
        Me.SEQ = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CODE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.STATUS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ButtonAtualizar = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridViewRelatorio, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.Controls.Add(Me.TextBoxPesquisa)
        Me.GroupBox1.Controls.Add(Me.LabelCodigoRef)
        Me.GroupBox1.Location = New System.Drawing.Point(368, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(467, 120)
        Me.GroupBox1.TabIndex = 11
        Me.GroupBox1.TabStop = False
        '
        'TextBoxPesquisa
        '
        Me.TextBoxPesquisa.Font = New System.Drawing.Font("Segoe UI", 17.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxPesquisa.Location = New System.Drawing.Point(17, 53)
        Me.TextBoxPesquisa.Name = "TextBoxPesquisa"
        Me.TextBoxPesquisa.Size = New System.Drawing.Size(430, 38)
        Me.TextBoxPesquisa.TabIndex = 8
        Me.TextBoxPesquisa.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'LabelCodigoRef
        '
        Me.LabelCodigoRef.AutoSize = True
        Me.LabelCodigoRef.Font = New System.Drawing.Font("Segoe UI", 17.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.LabelCodigoRef.Location = New System.Drawing.Point(186, 19)
        Me.LabelCodigoRef.Name = "LabelCodigoRef"
        Me.LabelCodigoRef.Size = New System.Drawing.Size(106, 31)
        Me.LabelCodigoRef.TabIndex = 7
        Me.LabelCodigoRef.Text = "Pesquisa"
        '
        'ButtonInicio
        '
        Me.ButtonInicio.BackColor = System.Drawing.Color.LightSteelBlue
        Me.ButtonInicio.FlatAppearance.BorderSize = 0
        Me.ButtonInicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonInicio.Font = New System.Drawing.Font("Segoe UI", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonInicio.Location = New System.Drawing.Point(12, 264)
        Me.ButtonInicio.Name = "ButtonInicio"
        Me.ButtonInicio.Size = New System.Drawing.Size(350, 120)
        Me.ButtonInicio.TabIndex = 10
        Me.ButtonInicio.Text = "Inicio"
        Me.ButtonInicio.UseVisualStyleBackColor = False
        '
        'ButtonPesquisar
        '
        Me.ButtonPesquisar.BackColor = System.Drawing.Color.PaleGreen
        Me.ButtonPesquisar.FlatAppearance.BorderSize = 0
        Me.ButtonPesquisar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonPesquisar.Font = New System.Drawing.Font("Segoe UI", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonPesquisar.Location = New System.Drawing.Point(12, 12)
        Me.ButtonPesquisar.Name = "ButtonPesquisar"
        Me.ButtonPesquisar.Size = New System.Drawing.Size(350, 120)
        Me.ButtonPesquisar.TabIndex = 9
        Me.ButtonPesquisar.Text = "Pesquisar"
        Me.ButtonPesquisar.UseVisualStyleBackColor = False
        '
        'DataGridViewRelatorio
        '
        Me.DataGridViewRelatorio.AllowUserToOrderColumns = True
        Me.DataGridViewRelatorio.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridViewRelatorio.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewRelatorio.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.SEQ, Me.CODE, Me.STATUS})
        Me.DataGridViewRelatorio.Location = New System.Drawing.Point(368, 138)
        Me.DataGridViewRelatorio.Name = "DataGridViewRelatorio"
        Me.DataGridViewRelatorio.ReadOnly = True
        Me.DataGridViewRelatorio.RowTemplate.Height = 25
        Me.DataGridViewRelatorio.Size = New System.Drawing.Size(467, 394)
        Me.DataGridViewRelatorio.TabIndex = 12
        '
        'SEQ
        '
        Me.SEQ.HeaderText = "SEQ"
        Me.SEQ.Name = "SEQ"
        Me.SEQ.ReadOnly = True
        '
        'CODE
        '
        Me.CODE.HeaderText = "CODE"
        Me.CODE.Name = "CODE"
        Me.CODE.ReadOnly = True
        '
        'STATUS
        '
        Me.STATUS.HeaderText = "STATUS"
        Me.STATUS.Name = "STATUS"
        Me.STATUS.ReadOnly = True
        '
        'ButtonAtualizar
        '
        Me.ButtonAtualizar.BackColor = System.Drawing.Color.DarkTurquoise
        Me.ButtonAtualizar.FlatAppearance.BorderSize = 0
        Me.ButtonAtualizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonAtualizar.Font = New System.Drawing.Font("Segoe UI", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ButtonAtualizar.Location = New System.Drawing.Point(12, 138)
        Me.ButtonAtualizar.Name = "ButtonAtualizar"
        Me.ButtonAtualizar.Size = New System.Drawing.Size(350, 120)
        Me.ButtonAtualizar.TabIndex = 13
        Me.ButtonAtualizar.Text = "Atualizar"
        Me.ButtonAtualizar.UseVisualStyleBackColor = False
        '
        'FormRelatorio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(839, 537)
        Me.Controls.Add(Me.ButtonAtualizar)
        Me.Controls.Add(Me.DataGridViewRelatorio)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ButtonInicio)
        Me.Controls.Add(Me.ButtonPesquisar)
        Me.Name = "FormRelatorio"
        Me.Text = "Relatório"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridViewRelatorio, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents TextBoxPesquisa As TextBox
    Friend WithEvents LabelCodigoRef As Label
    Friend WithEvents ButtonInicio As Button
    Friend WithEvents ButtonPesquisar As Button
    Friend WithEvents DataGridViewRelatorio As DataGridView
    Friend WithEvents SEQ As DataGridViewTextBoxColumn
    Friend WithEvents CODE As DataGridViewTextBoxColumn
    Friend WithEvents STATUS As DataGridViewTextBoxColumn
    Friend WithEvents ButtonAtualizar As Button
End Class
