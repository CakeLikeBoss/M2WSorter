﻿Public Class FormRelatorio
    Private Sub ButtonInicio_Click(sender As Object, e As EventArgs) Handles ButtonInicio.Click
        Me.Close()
    End Sub

    Private Sub FormRelatorio_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Atualizar()
    End Sub

    Private Sub ButtonAtualizar_Click(sender As Object, e As EventArgs) Handles ButtonAtualizar.Click
        Atualizar()
    End Sub

    Private Sub Atualizar()
        DataGridViewRelatorio.Rows.Clear()
        Dim x As Integer

        For x = 1 To FormInicio.csvManager.colSeq.Length - 1 Step 1
            If FormInicio.csvManager.colError(x) = "" Then
                DataGridViewRelatorio.Rows.Add(New Object() {
                    FormInicio.csvManager.colSeq(x),
                    FormInicio.csvManager.colCodigo(x),
                    "PENDENTE"
                })
            Else
                DataGridViewRelatorio.Rows.Add(New Object() {
                    FormInicio.csvManager.colSeq(x),
                    FormInicio.csvManager.colCodigo(x),
                    FormInicio.csvManager.colError(x)
                })
            End If
        Next
    End Sub

    Private Sub TextBoxPesquisa_KeyPress(sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxPesquisa.KeyPress
        If e.KeyChar = Convert.ToChar(13) Then
            Dim i As Integer
            Dim texto As String
            texto = TextBoxPesquisa.Text
            Pesquisar(texto)
        End If

    End Sub


    Private Sub Pesquisar(texto As String)
        Dim x As Integer
        For x = 0 To DataGridViewRelatorio.Rows.Count - 2 Step 1
            If DataGridViewRelatorio.Rows(x).Cells(0).Value.ToString.Contains(texto) Or DataGridViewRelatorio.Rows(x).Cells(1).Value.ToString.Contains(texto) Or DataGridViewRelatorio.Rows(x).Cells(2).Value.ToString.Contains(texto) Then
                DataGridViewRelatorio.Rows(x).Visible = True
            Else
                DataGridViewRelatorio.Rows(x).Visible = False
            End If
        Next

    End Sub

    Private Sub ButtonPesquisar_Click(sender As Object, e As EventArgs) Handles ButtonPesquisar.Click
        Pesquisar(TextBoxPesquisa.Text)
    End Sub
End Class